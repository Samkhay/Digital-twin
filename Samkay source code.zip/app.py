from flask import Flask, render_template, jsonify
import pandas as pd
import joblib
import threading
import time
from datetime import datetime


from digital_twin.combined_engine import (
    compute_transaction_risk,
    compute_network_risk,
    compute_atm_risk,
    compute_user_risk,
    propagate_attack,
    assess_impact,
    preventive_response
)


app = Flask(__name__)


# ============================================================
# LOAD DATASETS
# ============================================================

tx_df = pd.read_csv(
    "data_fraud/nigeria_bank_transactions.csv"
)

net_df = pd.read_csv(
    "data_fraud/nigeria_network_intrusion.csv"
)

atm_df = pd.read_csv(
    "data_fraud/nigeria_atm_operations.csv"
)

user_df = pd.read_csv(
    "data_fraud/nigeria_user_behavior.csv"
)


# ============================================================
# LOAD TRAINED MODELS
# ============================================================

tx_model = joblib.load(
    "models/anomaly_model.pkl"
)

net_model = joblib.load(
    "models/network_model.pkl"
)


# ============================================================
# DIGITAL TWIN RUNTIME STATE
# ============================================================

digital_twin_state = {

    "running": False,

    "cycle": 0,

    "started_at": None,

    "last_update": None,

    "simulation_time": None,

    "data": None
}


# Thread synchronization
twin_lock = threading.Lock()

# Background simulation thread
simulation_thread = None

# Simulation update interval in seconds
SIMULATION_INTERVAL = 3


# ============================================================
# NETWORK FEATURE ENCODING
# ============================================================

def encode_network_row(row):

    """
    Return numeric features required
    by the trained network model.
    """

    protocol_encoded = row.get(
        "protocol_encoded",
        0
    )

    bank_encoded = row.get(
        "bank_encoded",
        0
    )

    hour = row.get(
        "hour",
        0
    )

    severity_encoded = row.get(
        "severity_encoded",
        0
    )

    return {

        "protocol_encoded":
            protocol_encoded,

        "bank_encoded":
            bank_encoded,

        "hour":
            hour,

        "severity_encoded":
            severity_encoded

    }


# ============================================================
# GENERATE ONE DIGITAL-TWIN STATE
# ============================================================

def generate_twin_state():

    """
    Generates one new simulated state of the
    banking cybersecurity digital twin.

    Existing risk functions are not modified.
    """


    # --------------------------------------------------------
    # SAMPLE CURRENT SIMULATED OBSERVATIONS
    # --------------------------------------------------------

    tx = (
        tx_df
        .sample(1)
        .iloc[0]
        .to_dict()
    )

    net = (
        net_df
        .sample(1)
        .iloc[0]
        .to_dict()
    )

    atm = (
        atm_df
        .sample(1)
        .iloc[0]
        .to_dict()
    )

    user = (
        user_df
        .sample(1)
        .iloc[0]
        .to_dict()
    )


    # --------------------------------------------------------
    # INDIVIDUAL RISK CALCULATIONS
    # --------------------------------------------------------

    tx_risk = compute_transaction_risk(
        tx_model,
        tx
    )


    net_risk = compute_network_risk(
        net_model,
        encode_network_row(net)
    )


    atm_risk = compute_atm_risk(
        atm
    )


    user_risk = compute_user_risk(
        user
    )


    # --------------------------------------------------------
    # GLOBAL RISK
    #
    # Transaction = 40%
    # Network     = 30%
    # ATM         = 20%
    # User        = 10%
    # --------------------------------------------------------

    global_risk = round(

        0.4 * tx_risk
        +
        0.3 * net_risk
        +
        0.2 * atm_risk
        +
        0.1 * user_risk,

        2
    )


    # --------------------------------------------------------
    # DIGITAL TWIN PROCESSING
    # --------------------------------------------------------

    system = propagate_attack(
        global_risk
    )


    impact = assess_impact(
        global_risk,
        tx.get(
            "amount_naira",
            0
        )
    )


    action = preventive_response(
        global_risk
    )


    # --------------------------------------------------------
    # RETURN COMPLETE STATE
    # --------------------------------------------------------

    return {

        "tx": tx,

        "net": net,

        "atm": atm,

        "user": user,

        "tx_risk":
            round(tx_risk, 2),

        "net_risk":
            round(net_risk, 2),

        "atm_risk":
            round(atm_risk, 2),

        "user_risk":
            round(user_risk, 2),

        "global_risk":
            global_risk,

        "system":
            system,

        "impact":
            impact,

        "action":
            action

    }


# ============================================================
# BACKGROUND DIGITAL TWIN SIMULATION
# ============================================================

def digital_twin_worker():

    """
    Continuously generates new digital-twin states
    while the simulation is running.
    """

    while True:

        with twin_lock:

            running = digital_twin_state[
                "running"
            ]


        if not running:

            break


        try:

            new_state = generate_twin_state()

            now = datetime.now()


            with twin_lock:

                digital_twin_state[
                    "data"
                ] = new_state


                digital_twin_state[
                    "cycle"
                ] += 1


                digital_twin_state[
                    "last_update"
                ] = now.strftime(
                    "%Y-%m-%d %H:%M:%S"
                )


                digital_twin_state[
                    "simulation_time"
                ] = now.strftime(
                    "%H:%M:%S"
                )


        except Exception as error:

            print(
                "Digital Twin simulation error:",
                error
            )


        time.sleep(
            SIMULATION_INTERVAL
        )


# ============================================================
# START DIGITAL TWIN
# ============================================================

def start_digital_twin():

    global simulation_thread


    with twin_lock:

        # Already running
        if digital_twin_state[
            "running"
        ]:

            return False


        # Generate initial state immediately
        initial_state = (
            generate_twin_state()
        )


        now = datetime.now()


        digital_twin_state[
            "running"
        ] = True


        digital_twin_state[
            "cycle"
        ] += 1


        digital_twin_state[
            "started_at"
        ] = now.strftime(
            "%Y-%m-%d %H:%M:%S"
        )


        digital_twin_state[
            "last_update"
        ] = now.strftime(
            "%Y-%m-%d %H:%M:%S"
        )


        digital_twin_state[
            "simulation_time"
        ] = now.strftime(
            "%H:%M:%S"
        )


        digital_twin_state[
            "data"
        ] = initial_state


    # Start background worker

    simulation_thread = threading.Thread(

        target=digital_twin_worker,

        daemon=True

    )

    simulation_thread.start()


    return True


# ============================================================
# STOP DIGITAL TWIN
# ============================================================

def stop_digital_twin():

    with twin_lock:

        if not digital_twin_state[
            "running"
        ]:

            return False


        digital_twin_state[
            "running"
        ] = False


    return True


# ============================================================
# API: START DIGITAL TWIN
# ============================================================

@app.route(
    "/api/digital-twin/start",
    methods=["POST"]
)
def api_start_digital_twin():

    started = start_digital_twin()


    return jsonify({

        "success": True,

        "running":
            digital_twin_state[
                "running"
            ],

        "message":
            (
                "Digital Twin started successfully."
                if started
                else
                "Digital Twin is already running."
            )

    })


# ============================================================
# API: STOP DIGITAL TWIN
# ============================================================

@app.route(
    "/api/digital-twin/stop",
    methods=["POST"]
)
def api_stop_digital_twin():

    stopped = stop_digital_twin()


    return jsonify({

        "success": True,

        "running":
            digital_twin_state[
                "running"
            ],

        "message":
            (
                "Digital Twin stopped successfully."
                if stopped
                else
                "Digital Twin is already stopped."
            )

    })


# ============================================================
# API: CURRENT DIGITAL TWIN STATUS
# ============================================================

@app.route(
    "/api/digital-twin/status",
    methods=["GET"]
)
def api_digital_twin_status():

    with twin_lock:

        running = (
            digital_twin_state[
                "running"
            ]
        )

        cycle = (
            digital_twin_state[
                "cycle"
            ]
        )

        started_at = (
            digital_twin_state[
                "started_at"
            ]
        )

        last_update = (
            digital_twin_state[
                "last_update"
            ]
        )

        simulation_time = (
            digital_twin_state[
                "simulation_time"
            ]
        )

        data = (
            digital_twin_state[
                "data"
            ]
        )


    # No simulation has been started yet

    if data is None:

        return jsonify({

            "running":
                running,

            "cycle":
                cycle,

            "started_at":
                started_at,

            "last_update":
                last_update,

            "simulation_time":
                simulation_time,

            "data":
                None

        })


    # --------------------------------------------------------
    # Return dashboard-friendly data
    # --------------------------------------------------------

    return jsonify({

        "running":
            running,

        "cycle":
            cycle,

        "started_at":
            started_at,

        "last_update":
            last_update,

        "simulation_time":
            simulation_time,

        "data": {

            "tx_risk":
                float(data["tx_risk"]),

            "net_risk":
                float(data["net_risk"]),

            "atm_risk":
                float(data["atm_risk"]),

            "user_risk":
                float(data["user_risk"]),

            "global_risk":
                float(data["global_risk"]),

            "system":
                str(data["system"]),

            "impact":
                str(data["impact"]),

            "action":
                str(data["action"])

        }

    })


# ============================================================
# HOME
# ============================================================

@app.route("/")
def home():

    data = generate_twin_state()

    return render_template(
        "home.html",
        **data
    )


# ============================================================
# TRANSACTIONS
# ============================================================

@app.route("/transactions")
def transactions():

    data = generate_twin_state()

    return render_template(
        "transactions.html",
        **data
    )


# ============================================================
# NETWORK SECURITY
# ============================================================

@app.route("/network")
def network():

    data = generate_twin_state()

    return render_template(
        "network.html",
        **data
    )


# ============================================================
# ATM
# ============================================================

@app.route("/atm")
def atm():

    data = generate_twin_state()

    return render_template(
        "atm.html",
        **data
    )


# ============================================================
# USER BEHAVIOUR
# ============================================================

@app.route("/users")
def users():

    data = generate_twin_state()

    return render_template(
        "users.html",
        **data
    )


# ============================================================
# DIGITAL TWIN
# ============================================================

@app.route("/digital-twin")
def digital_twin():

    with twin_lock:

        data = digital_twin_state[
            "data"
        ]

        running = digital_twin_state[
            "running"
        ]

        cycle = digital_twin_state[
            "cycle"
        ]

        started_at = digital_twin_state[
            "started_at"
        ]

        last_update = digital_twin_state[
            "last_update"
        ]

        simulation_time = digital_twin_state[
            "simulation_time"
        ]


    # --------------------------------------------------------
    # No simulation state exists yet
    # --------------------------------------------------------

    if data is None:

        data = generate_twin_state()


    return render_template(

        "digital_twin.html",

        **data,

        twin_running=running,

        twin_cycle=cycle,

        twin_started_at=started_at,

        twin_last_update=last_update,

        twin_simulation_time=simulation_time

    )


# ============================================================
# APPLICATION START
# ============================================================

if __name__ == "__main__":

    app.run(
        debug=True,
        threaded=True
    )